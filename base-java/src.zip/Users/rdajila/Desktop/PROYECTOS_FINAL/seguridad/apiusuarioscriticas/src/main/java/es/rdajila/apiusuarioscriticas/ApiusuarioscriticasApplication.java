package es.rdajila.apiusuarioscriticas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiusuarioscriticasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiusuarioscriticasApplication.class, args);
	}

}
